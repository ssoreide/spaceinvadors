}

#else /* _UNIX */

static void glxewInfo ()
{
